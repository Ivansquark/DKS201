#ifndef EMUL_H
#define EMUL_H

#include <QTime>
#include <QTimer>


class Emul
{
public:
    Emul();
};

#endif // EMUL_H
