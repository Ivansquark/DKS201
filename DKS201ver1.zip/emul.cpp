#include "emul.h"

Emul::Emul()
{

}
